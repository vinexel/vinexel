<!DOCTYPE html>
<html>

<head>
    <title>About</title>
</head>

<body>
    <h1>About Page</h1>
    <nav>
        <a href="<?php echo BASE_URL; ?>/">Home</a>
        <a href="<?php echo BASE_URL; ?>/ini-about">About</a>
    </nav>
</body>

</html>