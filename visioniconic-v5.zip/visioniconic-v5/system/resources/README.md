This is a documentation project for your project, write here for all about logic code to easier programmer after you to maintain the every line of codes you write done.
